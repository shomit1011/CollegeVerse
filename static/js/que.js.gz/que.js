var phy=["loremepsum 1","loremepsum 2","loremepsum 3","loremepsum 4","loremepsum 5","loremepsum 6","loremepsum 7","loremepsum 8","loremepsum 9","loremepsum 10","loremepsum 11","loremepsum 12","loremepsum 13","loremepsum 14","loremepsum 15","loremepsum 16","loremepsum 17","loremepsum 18","loremepsum 19","loremepsum 20","loremepsum 21","loremepsum 22","loremepsum 23","loremepsum 24","loremepsum 25","loremepsum 26","loremepsum 27","loremepsum 28","loremepsum 29","loremepsum 30","loremepsum 31","loremepsum 32","loremepsum 33","loremepsum 34","loremepsum 35","loremepsum 36","loremepsum 37","loremepsum 38"]
var chem=["loremepsum 1","loremepsum 2","loremepsum 3","loremepsum 4","loremepsum 5","loremepsum 6","loremepsum 7","loremepsum 8","loremepsum 9","loremepsum 10","loremepsum 11","loremepsum 12","loremepsum 13","loremepsum 14","loremepsum 15","loremepsum 16","loremepsum 17","loremepsum 18","loremepsum 19","loremepsum 20","loremepsum 21","loremepsum 22","loremepsum 23","loremepsum 24","loremepsum 25","loremepsum 26","loremepsum 27","loremepsum 28","loremepsum 29","loremepsum 30","loremepsum 31","loremepsum 32","loremepsum 33","loremepsum 34","loremepsum 35","loremepsum 36","loremepsum 37","loremepsum 38"]
var math=["loremepsum 1","loremepsum 2","loremepsum 3","loremepsum 4","loremepsum 5","loremepsum 6","loremepsum 7","loremepsum 8","loremepsum 9","loremepsum 10","loremepsum 11","loremepsum 12","loremepsum 13","loremepsum 14","loremepsum 15","loremepsum 16","loremepsum 17","loremepsum 18","loremepsum 19","loremepsum 20","loremepsum 21","loremepsum 22","loremepsum 23","loremepsum 24","loremepsum 25","loremepsum 26","loremepsum 27","loremepsum 28","loremepsum 29","loremepsum 30","loremepsum 31","loremepsum 32","loremepsum 33","loremepsum 34","loremepsum 35","loremepsum 36","loremepsum 37","loremepsum 38"]

document.get


function net1(x){
  // document.getElementById("questions").innerHTML = math[x-1];
}
function net2(x){
  // document.getElementById("questions").innerHTML = chem[x-1];
}
function net3(x){
  // document.getElementById("questions").innerHTML = phy[x-1];
}
